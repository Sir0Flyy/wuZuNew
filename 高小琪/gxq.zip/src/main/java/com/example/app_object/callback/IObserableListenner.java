package com.example.app_object.callback;

public interface IObserableListenner<T> {
    void getObserable1Data(T t);
}
