package com.example.app_object.mvp.model.api;

/**
 * 存放公司API接口
 */
public class Constants {
   //index.php?tn=25017023_10_pg&ssl_s=1&ssl_c=ssl1_171577995ad
   public static final String BASE_URL="https://www.baidu.com/";
   public static  String BASE_URL1="https://wanandroid.com/";
   //公众号列表
   public static String CHAPTERS_LIST=BASE_URL1+"wxarticle/chapters/json";
}
